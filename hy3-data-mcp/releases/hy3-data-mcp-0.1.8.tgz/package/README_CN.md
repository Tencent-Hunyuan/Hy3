# Hy3 数据分析 MCP

[![npm](https://img.shields.io/npm/v/hy3-data-mcp.svg)](https://www.npmjs.com/package/hy3-data-mcp)
[![License](https://img.shields.io/badge/License-Apache%202.0-blue)](#license)
[![TypeScript](https://img.shields.io/badge/TypeScript-5.7-blue?logo=typescript)](#)
[![MCP](https://img.shields.io/badge/MCP-1.0+-green)](#)
[![Hy3](https://img.shields.io/badge/Powered%20by-Hy3-orange)](#)

> 让任意 CSV、JSON、Excel、PDF、Word 或文本文件，通过 **腾讯混元 Hy3** 驱动的 MCP 服务器，一键变成图表、数据大屏、词云、知识图谱和 AI 洞察。

**Hy3 数据分析 MCP** 是一个基于 [Model Context Protocol](https://modelcontextprotocol.io) 的服务端，它让你的 AI 助手拥有数据分析能力：你用自然语言提问，Hy3 完成推理，服务端渲染出可用于报告、网页或演示的 **SVG**、**HTML** 或 **PNG** 可视化结果。

![Demo](https://raw.githubusercontent.com/xy200303/Hy3/feat/add-hy3-data-mcp/hy3-data-mcp/assets/demo.gif)

本项目为 **2026 腾讯犀牛鸟开源人才培养活动** issue [Build an MCP Server powered by Hy3](https://github.com/Tencent-Hunyuan/Hy3/issues/3) 而开发。

---

## 为什么选择 Hy3 数据分析 MCP？

- **对话即可视化** —— 在 MCP 客户端里一句话就能生成图表、词云、知识图谱或数据大屏。
- **Hy3 负责思考** —— 字段选择、标题生成、关键词抽取、实体关系识别、大屏布局都交给 Hy3 模型完成。
- **多种输出格式** —— SVG 适合嵌入文档，HTML 可交互浏览，PNG 可直接放入 PPT 或社交媒体分享。
- **隐私优先** —— API Key 仅保存在本地 `.env` 文件中，代码中不硬编码任何密钥，也不会把数据发送到其他第三方服务。
- **兼容主流客户端** —— 支持 CodeBuddy、WorkBuddy、Cline、Cursor、Roo Code、Continue、Codex CLI、OpenCode 等任意 stdio MCP 客户端。

---

## 功能特性

| 工具 | 功能 | 输出格式 |
| --- | --- | --- |
| `hy3_data_visualize` | 读取结构化数据，生成柱状图、折线图、面积图、饼图、环形图、玫瑰图、散点图、气泡图、带趋势线的散点图、雷达图、热力图、漏斗图、桑基图、矩形树图、旭日图、仪表盘、直方图、箱线图、K 线图、堆叠柱状图、分组柱状图，以及 3D 柱状图/散点图/折线图（bar3d/scatter3d/line3d）和组合图（line_bar、area_bar、dual_axis、stacked_area、grouped_line）。 | `svg` / `html` / `png` |
| `hy3_wordcloud` | 由 Hy3 提取关键词及权重，渲染词云。 | `svg` / `html` / `png` |
| `hy3_knowledge_graph` | 由 Hy3 抽取实体与关系，渲染力导向知识图谱。 | `svg` / `html` / `png` |
| `hy3_data_dashboard` | 综合多个数据文件，由 Hy3 设计布局生成多图数据大屏。 | `html` / `png` |
| `hy3_data_report` | 从单个数据文件生成完整数据分析报告，包含 Hy3 撰写的洞察与嵌入式图表。 | `html` / `markdown` |
| `hy3_data_insight` | 对数据进行分析，返回趋势、异常点等文字洞察。 | `text` |
| `hy3_document_summary` | 总结或问答 PDF、DOCX、TXT、CSV、JSON、XLSX 文档。 | `text` / `html` |
| `hy3_document_visualize` | 从文档中提取结构化数据并生成图表或大屏。 | `svg` / `html` / `png` |

---

## 效果图展示

以下截图均使用 **Professional** 专业主题，基于仓库内置示例数据集直接渲染生成。

<table>
  <tr>
    <td align="center"><img src="https://raw.githubusercontent.com/xy200303/Hy3/feat/add-hy3-data-mcp/hy3-data-mcp/assets/screenshots/01-stacked-bar.png" width="420" alt="堆叠柱状图"><br/>分区域堆叠柱状图</td>
    <td align="center"><img src="https://raw.githubusercontent.com/xy200303/Hy3/feat/add-hy3-data-mcp/hy3-data-mcp/assets/screenshots/02-bubble.png" width="420" alt="气泡图"><br/>年龄与生命周期价值</td>
  </tr>
  <tr>
    <td align="center"><img src="https://raw.githubusercontent.com/xy200303/Hy3/feat/add-hy3-data-mcp/hy3-data-mcp/assets/screenshots/03-boxplot.png" width="420" alt="箱线图"><br/>临床试验响应分数箱线图</td>
    <td align="center"><img src="https://raw.githubusercontent.com/xy200303/Hy3/feat/add-hy3-data-mcp/hy3-data-mcp/assets/screenshots/04-candlestick.png" width="420" alt="K 线图"><br/>股票价格 K 线图</td>
  </tr>
  <tr>
    <td align="center"><img src="https://raw.githubusercontent.com/xy200303/Hy3/feat/add-hy3-data-mcp/hy3-data-mcp/assets/screenshots/05-funnel.png" width="420" alt="漏斗图"><br/>营销转化漏斗</td>
    <td align="center"><img src="https://raw.githubusercontent.com/xy200303/Hy3/feat/add-hy3-data-mcp/hy3-data-mcp/assets/screenshots/06-sunburst.png" width="420" alt="旭日图"><br/>区域/城市/品类旭日图</td>
  </tr>
  <tr>
    <td align="center"><img src="https://raw.githubusercontent.com/xy200303/Hy3/feat/add-hy3-data-mcp/hy3-data-mcp/assets/screenshots/07-radar.png" width="420" alt="雷达图"><br/>部门绩效雷达图</td>
    <td align="center"><img src="https://raw.githubusercontent.com/xy200303/Hy3/feat/add-hy3-data-mcp/hy3-data-mcp/assets/screenshots/08-wordcloud.png" width="420" alt="词云"><br/>关键词词云</td>
  </tr>
  <tr>
    <td align="center"><img src="https://raw.githubusercontent.com/xy200303/Hy3/feat/add-hy3-data-mcp/hy3-data-mcp/assets/screenshots/09-knowledge-graph.png" width="420" alt="知识图谱"><br/>知识图谱</td>
    <td align="center"><img src="https://raw.githubusercontent.com/xy200303/Hy3/feat/add-hy3-data-mcp/hy3-data-mcp/assets/screenshots/10-dashboard.png" width="420" alt="数据大屏"><br/>综合数据大屏</td>
  </tr>
  <tr>
    <td align="center"><img src="https://raw.githubusercontent.com/xy200303/Hy3/feat/add-hy3-data-mcp/hy3-data-mcp/assets/screenshots/11-bar3d.png" width="420" alt="3D 柱状图"><br/>3D 各品类营收</td>
    <td align="center"><img src="https://raw.githubusercontent.com/xy200303/Hy3/feat/add-hy3-data-mcp/hy3-data-mcp/assets/screenshots/12-scatter3d.png" width="420" alt="3D 散点图"><br/>3D 销量-营收-利润散点</td>
  </tr>
  <tr>
    <td align="center"><img src="https://raw.githubusercontent.com/xy200303/Hy3/feat/add-hy3-data-mcp/hy3-data-mcp/assets/screenshots/13-line3d.png" width="420" alt="3D 折线图"><br/>3D 销量-营收-利润折线</td>
    <td align="center"><img src="https://raw.githubusercontent.com/xy200303/Hy3/feat/add-hy3-data-mcp/hy3-data-mcp/assets/screenshots/14-line_bar.png" width="420" alt="折线+柱状组合图"><br/>月度营收与利润组合图</td>
  </tr>
  <tr>
    <td align="center"><img src="https://raw.githubusercontent.com/xy200303/Hy3/feat/add-hy3-data-mcp/hy3-data-mcp/assets/screenshots/15-dual_axis.png" width="420" alt="双轴组合图"><br/>品类营收利润双轴图</td>
    <td align="center"><img src="https://raw.githubusercontent.com/xy200303/Hy3/feat/add-hy3-data-mcp/hy3-data-mcp/assets/screenshots/16-stacked_area.png" width="420" alt="堆叠面积图"><br/>各区域月度营收堆叠面积图</td>
  </tr>
  <tr>
    <td align="center"><img src="https://raw.githubusercontent.com/xy200303/Hy3/feat/add-hy3-data-mcp/hy3-data-mcp/assets/screenshots/17-grouped_line.png" width="420" alt="分组折线图"><br/>各区域月度营收分组折线</td>
    <td align="center"><img src="https://raw.githubusercontent.com/xy200303/Hy3/feat/add-hy3-data-mcp/hy3-data-mcp/assets/screenshots/18-area_bar.png" width="420" alt="面积+柱状组合图"><br/>月度利润与营收面积柱状图</td>
  </tr>
  <tr>
    <td align="center" colspan="2"><img src="https://raw.githubusercontent.com/xy200303/Hy3/feat/add-hy3-data-mcp/hy3-data-mcp/assets/dashboard_2024_Sales___Profit_Dashboard_1783662671334.png" width="860" alt="2024 销售与利润大屏"><br/>2024 销售与利润数据大屏（PNG 合成图）</td>
  </tr>
</table>

---

## 安装

```bash
npm install -g hy3-data-mcp
```

启动 MCP 服务：

```bash
hy3-data-mcp
```

或免安装运行：

```bash
npx -y hy3-data-mcp
```

自动配置 MCP 客户端：

```bash
npx -y hdm init
# 或全局安装后
hdm init
```

`hdm init` 会自动扫描已安装的 MCP 宿主，如 Codex、Claude Code、Cursor、Cline、Roo Code、Continue、OpenCode 等，显示每个宿主的已配置/未配置状态，并支持一次性为多个客户端写入配置。

---

## 快速开始

### 1. 获取 API Key

前往 [TokenHub](https://tokenhub.tencentmaas.com) 注册并创建 Hy3 模型的 API Key。

### 2. 使用 `npx` 免安装运行

```bash
cp .env.example .env
# 编辑 .env，填入 HY3_API_KEY
npx -y hy3-data-mcp
```

### 3. 从 npm 安装

```bash
npm install -g hy3-data-mcp
hy3-data-mcp
```

### 4. 一键配置客户端

包内附带独立的 `hdm` CLI，用于自动配置 MCP 客户端：

```bash
# 不安装直接运行
npx -y hdm init

# 或全局安装后
hdm init
```

`hdm init` 会扫描系统中的 MCP 客户端（CodeBuddy、Cursor、Cline、Roo Code、Continue、Codex CLI、OpenCode 等），让你选择目标客户端，并自动写入 MCP 配置和 `.env` 文件。

---

## 配置说明

在项目根目录创建 `.env` 文件：

```dotenv
HY3_API_KEY=your-tokenhub-api-key
HY3_BASE_URL=https://tokenhub.tencentmaas.com/v1
HY3_MODEL=hy3-preview
HY3_OUTPUT_DIR=./hy3-data-output
```

| 变量 | 必填 | 默认值 | 说明 |
| --- | --- | --- | --- |
| `HY3_API_KEY` | 是 | — | TokenHub / Hy3 API Key。 |
| `HY3_BASE_URL` | 否 | `https://tokenhub.tencentmaas.com/v1` | OpenAI 兼容接口地址。 |
| `HY3_MODEL` | 否 | `hy3-preview` | 模型名。 |
| `HY3_OUTPUT_DIR` | 否 | `./hy3-data-output` | 生成文件的输出目录。 |

---

## 客户端接入

### CodeBuddy / WorkBuddy

在用户目录的 `~/.codebuddy/.mcp.json` 中写入：

```json
{
  "mcpServers": {
    "hy3-data-mcp": {
      "type": "stdio",
      "command": "npx",
      "args": ["-y", "hy3-data-mcp"],
      "env": {
        "HY3_API_KEY": "your-tokenhub-api-key",
        "HY3_BASE_URL": "https://tokenhub.tencentmaas.com/v1",
        "HY3_MODEL": "hy3-preview",
        "HY3_OUTPUT_DIR": "./hy3-data-output"
      }
    }
  }
}
```

### Cline / Cursor / Roo Code / Continue

运行 `hdm init` 自动配置。

### Open WebUI

Open WebUI 没有暴露可供 `hdm init` 直接写入的 stdio MCP 宿主。要在 Open WebUI 中使用 Hy3 数据分析 MCP，可以创建一个 Open WebUI [Function / Tool](https://docs.openwebui.com/features/plugin/functions/)，通过 `npx -y hy3-data-mcp` 启动子进程并代理 JSON-RPC 消息；或者单独运行服务端并通过管道转发 stdio。目前暂未提供 Open WebUI 的一键安装功能。

---

## 使用示例

### CSV 分析与可视化

```json
{
  "name": "hy3_data_visualize",
  "arguments": {
    "file_path": "./sales.csv",
    "chart_type": "bar",
    "output_format": "png",
    "language": "zh"
  }
}
```

### 桑基图

```json
{
  "name": "hy3_data_visualize",
  "arguments": {
    "file_path": "./sales.csv",
    "chart_type": "sankey",
    "output_format": "png",
    "language": "zh"
  }
}
```

### 科研箱线图

```json
{
  "name": "hy3_data_visualize",
  "arguments": {
    "file_path": "./sales.csv",
    "chart_type": "boxplot",
    "output_format": "png",
    "language": "zh"
  }
}
```

### 气泡图

```json
{
  "name": "hy3_data_visualize",
  "arguments": {
    "file_path": "./sales.csv",
    "chart_type": "bubble",
    "output_format": "png",
    "language": "zh"
  }
}
```

### 堆叠柱状图

```json
{
  "name": "hy3_data_visualize",
  "arguments": {
    "file_path": "./sales.csv",
    "chart_type": "stacked_bar",
    "output_format": "png",
    "language": "zh"
  }
}
```

### 直方图

```json
{
  "name": "hy3_data_visualize",
  "arguments": {
    "file_path": "./sales.csv",
    "chart_type": "histogram",
    "output_format": "png",
    "language": "zh"
  }
}
```

### K 线图

```json
{
  "name": "hy3_data_visualize",
  "arguments": {
    "file_path": "./stock.csv",
    "chart_type": "candlestick",
    "output_format": "png",
    "language": "zh"
  }
}
```

### 多文件数据大屏

```json
{
  "name": "hy3_data_dashboard",
  "arguments": {
    "file_paths": ["./sales.csv", "./users.csv"],
    "title": "月度运营大屏",
    "theme": "nature",
    "output_format": "html",
    "language": "zh"
  }
}
```

### 文本词云

```json
{
  "name": "hy3_wordcloud",
  "arguments": {
    "file_path": "./reviews.csv",
    "column": "comment",
    "max_words": 80,
    "output_format": "png",
    "language": "zh"
  }
}
```

### 文档总结

```json
{
  "name": "hy3_document_summary",
  "arguments": {
    "file_path": "./report.pdf",
    "question": "总结关键发现与风险",
    "output_format": "html",
    "language": "zh"
  }
}
```

### 生成完整数据分析报告

```json
{
  "name": "hy3_data_report",
  "arguments": {
    "file_paths": ["./sales.csv"],
    "question": "分析销售表现并总结关键驱动因素",
    "output_format": "html",
    "max_charts": 4,
    "theme": "professional",
    "language": "zh"
  }
}
```

### 3D 柱状图

```json
{
  "name": "hy3_data_visualize",
  "arguments": {
    "file_path": "./sales.csv",
    "chart_type": "bar3d",
    "output_format": "png",
    "language": "zh"
  }
}
```

### 3D 散点图

```json
{
  "name": "hy3_data_visualize",
  "arguments": {
    "file_path": "./sales.csv",
    "chart_type": "scatter3d",
    "x_column": "price",
    "y_column": "sales",
    "z_column": "profit",
    "output_format": "png",
    "language": "zh"
  }
}
```

### 双轴组合图

```json
{
  "name": "hy3_data_visualize",
  "arguments": {
    "file_path": "./sales.csv",
    "chart_type": "dual_axis",
    "x_column": "month",
    "y_column": "sales",
    "value_column": "profit",
    "output_format": "png",
    "language": "zh"
  }
}
```

---

## 输出格式说明

- **`svg`** —— 轻量、可缩放矢量图，适合嵌入报告或网页。
- **`html`** —— 基于 ECharts 的交互式页面，支持动画，可直接在浏览器打开。
- **`png`** —— 由 `sharp` 栅格化，适合 PPT、文档和社交分享。

---

## 主题与字体

所有可视化工具都支持 `theme` 参数和可选的 `font_family` 覆盖。

内置主题：

| 主题 | 风格 |
| --- | --- |
| `light` | 纯白背景，默认 ECharts 调色板。 |
| `dark` | 深色背景，高对比霓虹配色。 |
| `colorful` | 高饱和配色，适合演示。 |
| `minimal` | 低饱和、单色系友好配色。 |
| `professional` | 商务报告常用的石板灰配色。 |
| `premium` | 深海军蓝背景、精致渐变、圆角与现代专业配色。 |
| `retro` | 类似 Solarized 的暖色配色，搭配衬线字体。 |
| `science` | 绿色连续色板，搭配等宽字体。 |
| `nature` | **默认。** Nature 期刊风格，采用适合发表的 Tableau 色板与简洁排版。 |

Nature 默认主题 + 自定义字体示例：

```json
{
  "name": "hy3_data_visualize",
  "arguments": {
    "file_path": "./sales.csv",
    "chart_type": "bar",
    "output_format": "png",
    "theme": "nature",
    "font_family": "Inter",
    "language": "zh"
  }
}
```

### 自定义颜色

所有可视化工具还支持可选的颜色覆盖参数，方便匹配品牌色或用户偏好：

| 参数 | 说明 |
| --- | --- |
| `background_color` | 图表/页面背景色，如 `#ffffff`。 |
| `text_color` | 标题、标签、图例文字颜色，如 `#1a1a1a`。 |
| `axis_color` | 坐标轴线和刻度颜色，如 `#999999`。 |
| `split_line_color` | 网格分割线颜色，如 `#e8e8e8`。 |
| `palette` | 完整的自定义调色板，传入 HEX 颜色数组。 |
| `primary_color` | 快捷方式：替换当前主题调色板的第一个颜色。 |

自定义调色板示例：

```json
{
  "name": "hy3_data_visualize",
  "arguments": {
    "file_path": "./sales.csv",
    "chart_type": "bar",
    "output_format": "png",
    "theme": "nature",
    "palette": ["#1f77b4", "#ff7f0e", "#2ca02c", "#d62728"],
    "background_color": "#fafbfc",
    "text_color": "#222222",
    "font_family": "Inter"
  }
}
```

---

## 示例数据集

`sample_data/` 目录包含简单和复杂两类演示数据，覆盖所有图表类型：

- `sample_data/complex/ecommerce_sales.csv` —— 60 行多维电商销售数据（区域、品类、渠道、收入、利润、折扣）。
- `sample_data/complex/customers.csv` —— 80 条客户记录，含人口统计、细分、LTV、流失风险。
- `sample_data/complex/marketing_campaigns.csv` —— 24 条营销活动数据，含预算、曝光、点击、转化、收入。
- `sample_data/complex/clinical_trial.csv` —— 90 条临床试验患者记录，适合科研统计分析。
- `sample_data/complex/employee_performance.csv` —— 60 条员工绩效记录，含部门、职级、薪资、满意度。
- `sample_data/complex/hierarchical_geo_sales.csv` —— 区域 → 城市 → 品类 层级数据，适合矩形树图/旭日图。
- `sample_data/complex/reviews.csv` —— 20 条真实风格的中文产品评论，适合词云与情感分析。
- `sample_data/stock.csv` —— OHLC 股票数据，适合 K 线图。
- `sample_data/report.docx` —— 一份包含季度销售报表和表格的 Word 示例文档，用于测试 `hy3_document_summary` / `hy3_document_visualize`。
- `sample_data/report.pdf` —— 同一份报表的 PDF 版本，用于测试 PDF 解析与总结。

运行 `node scripts/generate-sample-data.mjs` 可确定性重新生成 CSV 数据集。运行 `python scripts/generate-sample-documents.py`（需 Python 环境安装 `python-docx` 和 `fpdf2`）可重新生成 DOCX/PDF 示例。

---

## 开发

```bash
git clone https://github.com/Tencent-Hunyuan/Hy3.git
cd Hy3/hy3-data-mcp
npm install
npm run build
npm test
npm run test:coverage   # 生成覆盖率报告
npm run test:real       # 需要配置 HY3_API_KEY
```

测试套件包含 **115+ 条单元、集成和冒烟测试**，覆盖文档解析、工具函数、主题系统、CLI 配置、数据大屏渲染、客户端初始化、全部可视化工具、图表渲染和 MCP Server 握手。按最新运行结果，`src/` 目录的语句覆盖率约为 **95%**、分支覆盖率约为 **85%**、函数覆盖率约为 **96%**（若计入未覆盖的辅助脚本，整体语句覆盖率约为 92%）。

使用 [MCP Inspector](https://github.com/modelcontextprotocol/inspector) 调试：

```bash
npx @modelcontextprotocol/inspector node dist/index.js
```

---

## 路线图

- [x] 7 个核心数据分析工具
- [x] SVG / HTML / PNG 三种输出格式
- [x] 命令行一键安装工具 `hdm init`
- [x] 支持 PDF、DOCX、XLSX、CSV、JSON、TXT 文档
- [x] 多种图表主题与自定义字体
- [x] 更多数据大屏布局
- [x] 长分析任务的流式进度反馈
- [x] UI 标签多语言自动检测

---

## 许可证

本项目采用 [Apache-2.0](../LICENSE) 许可证。
